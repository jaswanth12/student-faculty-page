import React from 'react'
import PropTypes from 'prop-types'

const Hr = () => {
	return (
		<hr style={{borderColor:"#45A29E",width:"100%"}}></hr>
	)
}


export default Hr