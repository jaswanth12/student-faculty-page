import React, { PropTypes } from 'react';
import { Link } from 'react-router-dom';
import Card from "../UiLayout/Card.js";
import FacultyHomePage from '../Faculty/FacultyHomePage';

const Faculty = () => {
    return (
    	<Card>
        <h1>Faculty Home Page</h1>
        </Card>
    );
};


export default Faculty;
