import React from 'react';
import PropTypes from 'prop-types';
import Card from "../UiLayout/Card.js";

const Students = props => {
	return (
		<Card>
			<h1>students Home page</h1>
		</Card>
	)
}

// students.propTypes = {

// }

export default Students